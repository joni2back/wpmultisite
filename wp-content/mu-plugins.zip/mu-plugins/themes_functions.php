<?php

add_filter('wp_prepare_themes_for_js', 'order_themes'); 
function order_themes($themes) {
    global $psts;

    //check if plugin or prosite is active
    if (! (function_exists('is_pro_site') && is_pro_site())) {
        return $themes;
    }

    //get the list of themes with their acceptance level
    $allowedThemes = get_blog_option(get_current_blog_id(), 'psts_blog_allowed_themes');

    //sort by level ([$themeName => $themeLevel])
    array_multisort($allowedThemes, \SORT_ASC);

    //by reference pushing real theme object preserving prev array order
    foreach ($allowedThemes as $allowedThemeName => &$allowedThemeLevel) {
        if (isset($themes[$allowedThemeName])) {
            $allowedThemeLevel = $themes[$allowedThemeName];
        } 
    }

    return $allowedThemes;
}